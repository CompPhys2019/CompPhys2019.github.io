MC program:  ising.f90 
result:      bin.dat
input file:  inp
Data analyse: res.f90
results:    比热： c.res, 磁化强度：m.res, Binder ratio: q.res, 内能密度：e.res
